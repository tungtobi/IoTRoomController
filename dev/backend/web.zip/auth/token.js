var mysql = require ("mysql");
var log = require ("../lib/log");

function query (sql, callback){
	var con = mysql.createConnection({
	  host: "localhost",
	  user: "apprunner",
	  password: "apprunner",
	  database: "app"
	});
	con.connect(function(err) {
	  if (err) {log.log (err); callback({"err_code": err});}

	  con.query(sql, function (err, result) {
	    if (err) callback({'error_code': err});
	    else callback({"error_code": 0, "result": result});
	  });
	  con.end();
	}); 
//	con.release();
}
function generate_token(length) {
   var result           = '';
   var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
   var charactersLength = characters.length;
   for ( var i = 0; i < length; i++ ) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
   }
   return result;
}

function validate_string (token){
	for (var i = 0; i < token.length; ++i){
		if (!((token.charCodeAt(i) >= 48 && token.charCodeAt(i) <= 57) || 
		    (token.charCodeAt(i) >= 97 && token.charCodeAt(i) <= 122) ||
		    (token.charCodeAt(i) >= 65 && token.charCodeAt(i) <= 90)))
			return false;
	}
	return true;
}
function verify_token(token, callback){
		if (validate_string (token)){
			query ("select * from tokens where token = '" + token + "' and created_time > NOW() - INTERVAL 30 DAY", function (result){
				log.log (result);
				if (result.error_code === 0)
				{
					if (result.result.length === 1){
						callback({"error_code": 0, "valid": true});
					} else {callback({"error_code": 104, "valid": false});}
				} else {callback({"error_code": 104, "valid": false});}
			});
		} else callback({"error_code": 104, "valid": false});
}
exports.verify_token = verify_token;
exports.create_token = function (credentials, callback){
	log.log(credentials);
	if (validate_string(credentials.username) && validate_string(credentials.password)){
		query ("select * from users where username = '" + credentials.username + "' and password = '" + credentials.password + "'", 
			function (result){
				log.log(result);
				if (result.error_code !== 0 ){callback({"error_code": 100});}
				else if (result.result.length !== 1){callback({"error_code": 101});}
				else {
					var new_token = generate_token (128);
					query ("insert into tokens value ('" + new_token + "', '" + credentials.username + "', null)", function (result){
						if (result.error_code === 0){
							callback ({"error_code": 0, "token": new_token});
						}
						else callback({"error_code": 100});
					});
				}
		});
	}
	else callback({"error_code": 101});
}

exports.delete_token = function (token, callback){
	verify_token (token, function(result){
		log.log (result);
		if (result.valid === true){
			query("delete from tokens where token = '" + token + "'", function (result){
				if (result.error_code !== 0) {callback({"error_code": 100});}
				else {callback({"error_code": 0});}
			});
		} else {callback({"error_code": 104});}
	});
}
exports.delete_token_for_user = function (username, callback){
                        query("delete from tokens where username = '" + username + "'", function (result){
                                if (result.error_code !== 0) {callback({"error_code": 100});}
                                else {callback({"error_code": 0});}
                        });
}
