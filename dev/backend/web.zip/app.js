var express = require('express');
var app = express();
var auth = require ('./auth/token');
var bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.post('/login', function (req, res) {
	auth.create_token (req.body, function (result){
		res.end (JSON.stringify(result)); 
	});
})
app.get ('/logout', function (req, res){
	if (req.query.token !== undefined){
	auth.delete_token (req.query.token, function (result){
		res.end (JSON.stringify(result));	
	});	}

        if (req.query.user !== undefined){
        auth.delete_token_for_user (req.query.user, function (result){
                res.end (JSON.stringify(result));       
        });     }

})
app.use(express.static('public'));

app.get('/', function(req, res){
	res.redirect("/index.html");
});
app.get('/*', function (req, res){
	res.end(JSON.stringify({"error_code": 404}));
});
app.post('/*', function (req, res){
        res.end(JSON.stringify({"error_code": 404}));
});
var server = app.listen(3000, function () {
   var host = server.address().address
   var port = server.address().port
   
   console.log("App is listening at http://%s:%s", host, port)
})
